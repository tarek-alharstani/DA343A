package Server.Boundary;

import javax.swing.*;
import java.awt.*;
import java.io.*;
import java.text.SimpleDateFormat;
import java.util.Date;

/**
 * This class represents the GUI of the serverlog.
 * It logs all the traffic of the server to the gui.
 */
public class ServerLogGui extends JFrame{
    private JFrame frame;
    private JTextArea logTextArea;
    private JButton btnSearch = new JButton("Search"), btnClear = new JButton("Clear");

    /**
     * This is the constructor for this class the frame.
     */
    public ServerLogGui() {
        initializeUI();
    }

    /**
     * This method creates the frame of this gui with preferred sizes etc.
     */
    public void initializeUI() {
        frame = new JFrame("Server Log");
        frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        frame.setSize(600, 600);

        logTextArea = new JTextArea();
        logTextArea.setEditable(false);

        JScrollPane scrollPane = new JScrollPane(logTextArea);
        frame.add(scrollPane, BorderLayout.CENTER);

        JPanel buttonPanel = new JPanel();

        btnSearch.addActionListener(e -> {
            String startTime = JOptionPane.showInputDialog(frame, "Enter start time (HH:mm:ss):");
            String endTime = JOptionPane.showInputDialog(frame, "Enter end time (HH:mm:ss):");
            searchBetweenTimes(startTime, endTime);
        });

        btnClear.addActionListener(e -> {
            logTextArea.setText("");
            clearLogFile();
        });

        buttonPanel.add(btnSearch);
        buttonPanel.add(btnClear);

        frame.add(buttonPanel, BorderLayout.NORTH);

        loadLogFromFile();

        frame.setVisible(true);
    }

    /**
     * Gives you the ability to search through all the logs in the gui to search for specific logs.
     * @param startTime
     * @param endTime
     */
    private void searchBetweenTimes(String startTime, String endTime) {
        try {
            SimpleDateFormat dateFormat = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss");
            Date start = dateFormat.parse(dateFormat.format(new Date()).split(" ")[0] + " " + startTime);
            Date end = dateFormat.parse(dateFormat.format(new Date()).split(" ")[0] + " " + endTime);

            StringBuilder searchResults = new StringBuilder();
            String[] logs = logTextArea.getText().split("\n");

            for (String log : logs) {
                String timestamp = log.split(" - ")[0];
                Date logDate = dateFormat.parse(timestamp);
                if (logDate.after(start) && logDate.before(end) || logDate.equals(start) || logDate.equals(end)) {
                    searchResults.append(log).append("\n");
                }
            }
            if (searchResults.length() > 0) {
                showSearchResults(searchResults.toString());
            } else {
                JOptionPane.showMessageDialog(frame, "No logs found in the specified time range.");
            }
        } catch (Exception ex) {
            JOptionPane.showMessageDialog(frame, "Invalid time format.");
        }
    }

    /**
     * Opens a dialog window and shows the logs you searched for in the method above.
     * @param results
     */
    private void showSearchResults(String results) {
        JDialog resultsDialog = new JDialog(frame, "Search Results", true);
        JTextArea resultsTextArea = new JTextArea(results);
        resultsTextArea.setEditable(false);
        JScrollPane scrollPane = new JScrollPane(resultsTextArea);
        resultsDialog.add(scrollPane);
        resultsDialog.setSize(400, 300);
        resultsDialog.setLocationRelativeTo(frame);
        resultsDialog.setVisible(true);
    }

    /**
     * This method will be used to log anything you wnant yo the gui.
     * @param message
     */
    public void log(String message) {
        SwingUtilities.invokeLater(() -> {
            String timeStamp = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss").format(new Date());
            String formattedMessage = timeStamp + " - " + message + "\n";

            if (!logTextArea.getText().contains(formattedMessage)) {
                logTextArea.append(formattedMessage);
                saveLogToFile(formattedMessage);
            }
        });
    }

    /**
     * Gives you the ability to save the log to the files directory.
     * @param message
     */
    private void saveLogToFile(String message) {
        try (BufferedWriter writer = new BufferedWriter(new FileWriter("files/serverLog.txt", true))) {
            writer.write(message);
        } catch (IOException e) {
            e.printStackTrace();
            JOptionPane.showMessageDialog(frame, "Could not save to log file.", "Error", JOptionPane.ERROR_MESSAGE);
        }
    }

    /**
     * This clears all the logs in the file.
     */
    private void clearLogFile() {
        try (BufferedWriter writer = new BufferedWriter(new FileWriter("files/serverLog.txt"))) {

        } catch (IOException e) {
            e.printStackTrace();
            JOptionPane.showMessageDialog(frame, "Could not clear the log file.", "Error", JOptionPane.ERROR_MESSAGE);
        }
    }

    /**
     * When you start this gui it loads all previous logs from the file.
     */
    private void loadLogFromFile() {
        String logFileName = "files/serverLog.txt";
        try (BufferedReader reader = new BufferedReader(new FileReader(logFileName))) {
            String line;
            while ((line = reader.readLine()) != null) {
                logTextArea.append(line + "\n");
            }
        } catch (IOException e) {
            System.out.println("Could not read log file: " + e.getMessage());
        }
    }
}