package Server.Entity;

import Global.Message;
import Global.User;

import java.util.ArrayList;
import java.util.HashMap;

/**
 * This class represents the entity class of the unsent
 * messages that will be stored in this class.
 */
public class UnsentMessage {
    private HashMap<User, ArrayList<Message>> unsent = new HashMap<>();

    /**
     * This method is used to put the message and the user in the hashmap.
     * @param user
     * @param message
     */
    public synchronized void put(User user, Message message) {
        if (findUser(user)) {
            findList(user).add(message);
        } else {
            ArrayList<Message> list = new ArrayList<Message>();
            unsent.put(user, list);
            findList(user).add(message);
        }
    }

    /**
     * This method returns all the unsent messages for the user.
     * @param user
     * @return
     */
    public synchronized ArrayList<Message> findList(User user) {
        return unsent.get(user);
    }

    /**
     * This method is used to extract the message of the user that is in the hashmap.
     * @param user
     * @return
     */
    public synchronized ArrayList<Message> get(User user) {
        return unsent.remove(user);
    }

    /**
     * This method is used to find the specific user in the hashmap and returns its key value.
     * @param user
     * @return
     */
    public synchronized boolean findUser(User user) {
        return unsent.containsKey(user);
    }

    /**
     * This method removes the unsend message from the list as soon as the message is sent
     * to the user.
     * This is to make sure the same user doesn't get duplicate messages.
     * @param user
     * @param message
     */
    public synchronized void removeMessage(User user, Message message) {
        if (findUser(user)) {
            ArrayList<Message> list = findList(user);
            list.remove(message);
            if (list.isEmpty()) {
                unsent.remove(user);
            }
        }
    }


}