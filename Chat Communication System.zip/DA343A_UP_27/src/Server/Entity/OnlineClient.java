package Server.Entity;

import Global.User;
import Server.Controller.ClientHandler;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.Map;

/**
 * This class represents the entity class for the online clients
 */
public class OnlineClient {
    private HashMap<User, ClientHandler> onlineClients = new HashMap<User, ClientHandler>();

    /**
     * This takes in the argument user and ClientHandler and puts that specific user to the list.
     * @param user
     * @param connectedClient
     */
    public synchronized void addOnlineClient(User user, ClientHandler connectedClient){
        onlineClients.put(user, connectedClient);
    }

    /**
     * This method is used to be able to access/get the specific user that are in the list.
     * @param user
     * @return
     */
    public synchronized ClientHandler getConnectedClient(User user){
        return onlineClients.get(user);
    }

    /**
     * This method
     * @param connectedClient
     * @return
     */
    public synchronized boolean removeOnlineClient(ClientHandler connectedClient) {
        boolean deleted = false;
        deleted = onlineClients.entrySet().removeIf(entry -> entry.getValue() == connectedClient);
        if (deleted) {
            System.out.println("Client deleted");
        }
        return deleted;
    }


    /**
     * This method is to find the user that is in the list
     * with the key of the user that is in the hashmap.
     * @param user
     * @return
     */
    public synchronized boolean findUser(User user){
        return onlineClients.containsKey(user);
    }

    /**
     * This method is to loop through the HashMap and send the list of all the connected clients
     * that are in this list.
     * @return
     */
    public synchronized ArrayList<User> getOnlineClientsList(){
        ArrayList<User> onlineUsers = new ArrayList<User>();
        for (User user : onlineClients.keySet()){
            onlineUsers.add(user);
        }
        return onlineUsers;
    }

    /**
     * This method is used to pick up connected client by iterating over the HashMap and
     * returns the client.
     * @param connectedClient
     * @return
     */
    public synchronized User getUserByHandler(ClientHandler connectedClient) {
        for (Map.Entry<User, ClientHandler> entry : onlineClients.entrySet()) {
            if (entry.getValue().equals(connectedClient)) {
                return entry.getKey();
            }
        }
        return null;
    }

}
