package Server.Controller;

import Global.Message;
import Global.User;

import java.io.IOException;
import java.io.ObjectInputStream;
import java.io.ObjectOutputStream;
import java.net.Socket;

/**
 * This class represents one of the main cores of this system.
 * It opens up a socket for each cliented client.
 */
public class ClientHandler {

    private ConnectedClient connectedClient;
    private ServerController serverController;
    private Socket socket;
    private ObjectOutputStream oos;

    /**
     * Initializes the socket and servercontroller. Creates an ObjectOutputStream to send data.
     * It creates an instance of ConnectedClient class and starts the thread to listen for clients.
     *
     * @param socket
     * @param serverController
     */
    public ClientHandler(Socket socket, ServerController serverController) {
        try {
            this.socket = socket;
            this.serverController = serverController;
            oos = new ObjectOutputStream(socket.getOutputStream());
            connectedClient = new ConnectedClient();
            connectedClient.start();
        } catch (IOException e) {
            e.printStackTrace();
        }
    }

    /**
     * This method is to send data which could be anything to the clients.
     *
     * @param o
     */
    public void sendObject(Object o) {
        try {
            oos.writeObject(o);
            oos.flush();
        } catch (IOException e) {
            e.printStackTrace();
        }
    }

    /**
     * THis method will close the socket and remove the client from the system.
     *
     * @throws IOException
     */
    public void disconnect() throws IOException {
        if (!socket.isClosed() && socket.isConnected()) {
            try {
                socket.close();
            } catch (IOException e) {
                e.printStackTrace();
            }
        }
        if (connectedClient != null) {
            connectedClient.interrupt();
            connectedClient = null;
        }
        serverController.removeClient(ClientHandler.this);
    }


    public class ConnectedClient extends Thread {
        /**
         * This class will communicate with the clients.
         */
        private ObjectInputStream ois;
        private Object object;

        /**
         * This method will handle the clients.
         * It reads the the incoming data of the clients.
         * If it is an instance of User it logins the user to the system.
         * If it is an instance of the message it makes sure to send the message
         * with the servercontroller.
         */
        @Override
        public void run() {
            System.out.println("Listening to clients");
            try {
                ois = new ObjectInputStream(socket.getInputStream());
                object = ois.readObject();
            } catch (IOException | ClassNotFoundException e) {
                e.printStackTrace();
            }

            while (!Thread.interrupted()) {
                try {
                    object = ois.readObject();
                    if (object instanceof User) {
                        User u = (User) object;
                        serverController.loginUser(u, ClientHandler.this);
                    } else if (object instanceof Message) {
                        Message message = (Message) object;
                        message.setReceivedTime();
                        serverController.sendMessage(message);
                    } else {
                        disconnect();
                    }
                } catch (IOException e) {
                    try {
                        disconnect();
                    } catch (IOException ex) {
                        throw new RuntimeException(ex);
                    }
                } catch (Exception e) {
                    e.printStackTrace();
                }
            }
            try {
                disconnect();
            } catch (IOException e) {
                throw new RuntimeException(e);
            }
            System.out.println("CLOSING THREAD");
        }
    }
}

