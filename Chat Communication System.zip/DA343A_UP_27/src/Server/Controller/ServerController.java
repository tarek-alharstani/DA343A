package Server.Controller;

import Global.Message;
import Global.User;
import Server.Boundary.ServerLogGui;
import Server.Entity.OnlineClient;
import Server.Entity.UnsentMessage;

import java.io.IOException;
import java.net.InetAddress;
import java.net.ServerSocket;
import java.net.UnknownHostException;
import java.util.ArrayList;

/**
 * This is the main logic of the server class which uses thread.
 *
 */
public class ServerController extends Thread {
    private OnlineClient clients = new OnlineClient();
    private UnsentMessage unsent = new UnsentMessage();
    private ServerLogGui gui;

    /**
     * This constructor initializes this class and creates an instance of the Server class.
     * It opens up the serverloggui.
     * @param port
     */
    public ServerController(int port) throws UnknownHostException {
        new Server(port);
        try {
            gui = new ServerLogGui();
        } catch (Exception e) {
            e.printStackTrace();
        }
        gui.log("Server active!");
        gui.log("Running on port: " + port);
        gui.log("Running on ip: " + InetAddress.getLocalHost());
    }

    /**
     * With this user it logs in the user to the system.
     * It adds the client to the onlineclients list.
     * Sends the new online clientlist and also all unsent messages.
     * @param user
     * @param clientHandler
     * @throws IOException
     */
    public void loginUser(User user, ClientHandler clientHandler) throws IOException {
        if (!clients.findUser(user)) {
            clients.addOnlineClient(user, clientHandler);
            gui.log(user.getUserId() + " Has logged in");
            sendOnlineList();
            sendUnsentMessages(user);
        } else {
            clientHandler.sendObject("Username used");
            clientHandler.disconnect();
            gui.log(user.getUserId() + " Logging in denied");
        }
    }

    /**
     * This method removes the client from the clients list.
     * @param clientHandler
     */
    public void removeClient(ClientHandler clientHandler) {
        User user = clients.getUserByHandler(clientHandler);
        if (user != null && clients.removeOnlineClient(clientHandler)) {
            sendOnlineList();
            gui.log(user.getUserId() + " disconnected");
        }
    }

    /**
     * This method loops through all the online list of the connected clients and sends them
     * to the connected clients.
     */
    public void sendOnlineList() {
        ArrayList<User> onlineList = clients.getOnlineClientsList();
        for (User u : onlineList) {
            ClientHandler clientHandler = clients.getConnectedClient(u);
            clientHandler.sendObject(onlineList);
            gui.log(" Online-list sent to all members");
        }
    }

    /**
     * This method sends message to the client.
     * It uses the sendObject method which sends the method as an object.
     * @param message
     */
    public synchronized void sendMessage(Message message) {
        for (User user : message.getReceivers()) {
            if (clients.findUser(user)) {
                try {
                    clients.getConnectedClient(user).sendObject(message);
                    gui.log(" Message sent from: " + message.getSender().toString() + " to: " + message.getReceivers().toString());
                } catch (Exception e) {
                    e.printStackTrace();
                }
            } else {
                unsent.put(user, message);
                gui.log(message.getSender() + " stored a message for: " + message.getReceivers().toString() + " until client's back online");
            }
        }
    }

    /**
     * This method sends all the unsend messages which are found for the specific user.
     * It gets the unsent messages for the user and puts them in an array and sends them.
     * @param user
     */
    public void sendUnsentMessages(User user) {
        if (unsent.findUser(user)) {
            ArrayList<Message> unsentMessages = new ArrayList<>(unsent.get(user));
            for (Message m : unsentMessages) {
                try {
                    clients.getConnectedClient(user).sendObject(m);
                    gui.log("Sent message from storage to: " + user.getUserId());
                    unsent.removeMessage(user, m);
                } catch (Exception e) {
                    e.printStackTrace();
                }
            }
        }
    }

    private class Server extends Thread {
        /**
         * This class represents the start of the server.
         */
        private ServerSocket serverSocket;

        /**
         * This is the constructor where we create an instance of the Serversocket and runs it
         * with a specific port.
         * @param port
         */
        public Server(int port) {
            try {
                serverSocket = new ServerSocket(port);
                start();
            } catch (IOException e) {
                e.printStackTrace();
            }
        }

        /**
         * While the thread that runs the server is not interrupted it creates an instance of
         * clienthandler and accepts the sockets that requests to be connected.
         */
        public void run() {
            while (!Thread.interrupted()) {
                try {
                    new ClientHandler(serverSocket.accept(), ServerController.this);
                } catch (IOException e) {
                    e.printStackTrace();
                }
            }
        }
    }
}
