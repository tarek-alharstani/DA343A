package Server.Controller;

import java.net.UnknownHostException;

public class MainProgram {
    public static void main(String[] args) throws UnknownHostException {
        ServerController serverController = new ServerController(2243);
    }
}

