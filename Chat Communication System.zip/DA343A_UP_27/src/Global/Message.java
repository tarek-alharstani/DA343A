package Global;

import javax.swing.*;
import java.io.Serializable;
import java.time.LocalDateTime;
import java.util.ArrayList;

/**
 * This class represents what every Message object will be based on.
 */
public class Message implements Serializable {
    private String text;
    private ImageIcon image;
    private User sender;
    private ArrayList<User> receivers;
    private String receivedTime;

    /**
     *
     * @param text Uses a String for the texts
     * @param receivers Uses an ArrayList of Users for receivers
     * @param sender Uses a user instance
     * @param image Uses an imageicon.
     */
    public Message(String text, ArrayList<User> receivers, User sender, ImageIcon image) {
        this.text = text;
        this.receivers = receivers;
        this.sender = sender;
        this.image = image;
    }

    /**
     *
     * @return returns text
     */
    public String getText() {
        return text;
    }

    /**
     *
     * @return returns image
     */
    public ImageIcon getImage() {
        return image;
    }

    /**
     *
     * @return returns the sender
     */
    public User getSender() {
        return sender;
    }

    /**
     *
     * @return returns the receivers
     */
    public ArrayList<User> getReceivers() {
        return receivers;
    }

    /**
     * sets the received time and uses the local time of now.
     */
    public void setReceivedTime() {
        this.receivedTime = LocalDateTime.now().toString();
    }

    /**
     * A tostring method that returns how the message will be displayed.
     * @return
     */
    @Override
    public String toString() {
        return "Sent by: " + sender + " to" + receivers;
    }
}
