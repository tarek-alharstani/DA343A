package Global;

import javax.swing.*;
import java.io.Serializable;

/**
 * This class represents the User object that will be used for each client.
 */
public class User implements Serializable {
    private String userId;
    private ImageIcon image;

    /**
     * This constructor initiates the user object with an id and an image
     * @param userId Every client has an id
     * @param image Every client has an image
     */
    public User(String userId, ImageIcon image) {
        this.userId = userId;
        this.image = image;
    }

    /**
     * Method to get the user id.
     * @return returns a user id
     */
    public String getUserId() {
        return userId;
    }

    /**
     *
     * @return returns the hasCode for every user id.
     */
    @Override
    public int hashCode() {
        return userId.hashCode();
    }


    @Override
    public boolean equals(Object obj) {
        if(obj instanceof User){
            return userId.equals(((User) obj).getUserId());
        }
        return false;
    }

    public String toString() {
        return userId;
    }
}

