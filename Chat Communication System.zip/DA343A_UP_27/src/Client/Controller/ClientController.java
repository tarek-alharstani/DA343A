package Client.Controller;

import Client.Boundary.LoginScreen;
import Client.Boundary.UsersWindow;
import Global.Message;
import Global.User;

import javax.swing.*;
import java.beans.PropertyChangeListener;
import java.beans.PropertyChangeSupport;
import java.io.*;
import java.net.Socket;
import java.util.ArrayList;
import java.util.List;
import java.util.stream.Collectors;

/**
 * This class represents the logic of the client side. This class will be communicating with the server.
 */
public class ClientController {
    private Socket socket;
    private User user;
    private Message message;
    private String ip;
    private int port;
    private UsersWindow usersWindow;
    private ArrayList<User> onlineUsers = new ArrayList<>();
    private ArrayList<User> savedUsers = new ArrayList<>();
    private LoginScreen loginScreen;
    private Thread inputStream;
    private ObjectInputStream ois;
    private ObjectOutputStream oos;
    private PropertyChangeSupport pcs;
    private String name;
    private String imagePath;

    /**
     * This is the constructor where we initialize the arguments.
     * Registers this class as a listened.
     * It also created the instance of the userswindow.
     * @param ip
     * @param port
     * @param name
     * @param imagePath
     */
    public ClientController(String ip, int port, String name, String imagePath) {
        pcs = new PropertyChangeSupport(this);
        this.ip = ip;
        this.port = port;
        this.name = name;
        this.imagePath = imagePath;
        usersWindow = new UsersWindow(this, name, imagePath);
    }

    /**
     * This is the method where when the user tries to connect to the server.
     * @param name
     * @param path
     * @return
     */
    public boolean connect(String name, String path) {
        try {
            socket = new Socket(ip, port);
            user = null;
            user = new User(name, new ImageIcon(path));
            try {
                oos = new ObjectOutputStream(socket.getOutputStream());
                ois = new ObjectInputStream(socket.getInputStream());
                oos.flush();
                oos.writeObject(user);
                oos.flush();
                oos.writeObject(user);
                if (inputStream == null) {
                    inputStream = new Connection();
                    inputStream.start();
                }
            } catch (IOException e) {
                e.printStackTrace();
                return false;
            }
        } catch (Exception e) {
            System.out.println(e.toString());
            usersWindow.closeChatWindow();
            usersWindow.dispose();
            JOptionPane.showMessageDialog(null, "Unable to connect to the server: " + e.getMessage(), "Connection Error", JOptionPane.ERROR_MESSAGE);
            return false;
        }
        return true;
    }

    /**
     * This is the logic of when the user tries to send a message.
     * @param text
     * @param receiversId
     * @param image
     */
    public synchronized void sendMessage(String text, ArrayList<String> receiversId, ImageIcon image){
        try {
            ArrayList<User> receivers = new ArrayList<>();

            for(String receiverName : receiversId){
                for(User onlineUser : onlineUsers){
                    if(receiverName.equals(onlineUser.getUserId())){
                        receivers.add(onlineUser);
                    }
                }
                for (User savedContact : savedUsers){
                    if (receiverName.equals(savedContact.getUserId()) && !receivers.contains(savedContact)){
                        receivers.add(savedContact);
                    }
                }
            }

            Message newMessage = new Message(text, receivers, user, image);
            oos.writeObject(newMessage);
            oos.flush();
            System.out.println("Message sent");
        } catch (IOException e) {
            e.printStackTrace();
        }
    }

    /**
     * When a user saves a contact it creates a bin file in the contacts file with the users unique userid.
     * @param username
     */
    public void saveContact(String username){
        String filePath = "contacts/" + user.getUserId() + ".bin";
        File file = new File(filePath);
        ArrayList<User> allUsers = new ArrayList<>();

        if(file.exists()){
            try(ObjectInputStream input = new ObjectInputStream(new FileInputStream(file))){

                while(true){
                    try {
                        User user = (User) input.readObject();
                        allUsers.add(user);
                    } catch (EOFException e) {
                        break;
                    }
                }
            } catch (EOFException e) {
            } catch (Exception e) {
                e.printStackTrace();
            }
        }

        for(User user : onlineUsers){
            if(user.getUserId().equals(username) && !allUsers.contains(user)){
                allUsers.add(user);
                break;
            }
        }

        try(ObjectOutputStream output = new ObjectOutputStream(new FileOutputStream(filePath))){
            for(User user : allUsers){
                output.writeObject(user);
            }
        } catch (IOException e) {
            e.printStackTrace();
        }
    }

    /**
     * This method loads the saved contacts from the file.
     * @return
     */
    public ArrayList<String> getSavedContacts(){
        ArrayList<String> userNames = new ArrayList<>();
        savedUsers.clear();
        File file = new File("contacts/" + user.getUserId() + ".bin");
        if(file.exists() && file.length() > 0) {
            try (ObjectInputStream input = new ObjectInputStream(new FileInputStream(file))){
                while(true){
                    try {
                        User user = (User) input.readObject();
                        savedUsers.add(user);
                        userNames.add(user.getUserId());
                    } catch (EOFException e) {
                        break;
                    }
                }
            } catch (EOFException e) {
                System.out.println("Reached end of file");
            } catch (IOException | ClassNotFoundException e) {
                e.printStackTrace();
            }
        } else {
            System.out.println("File does not exist or is empty");
        }
        return userNames;
    }

    /**
     * This method is used to be able to get all the online users to be shown in the userswindow.
     * @return
     */
    public List<String> getOnlineUserIds() {
        return onlineUsers.stream().map(User::getUserId).collect(Collectors.toList());
    }

    /**
     * Method for the propertychangelistener.
     * @param listener
     */
    public void addPropertyChangeListener(PropertyChangeListener listener) {
        pcs.addPropertyChangeListener(listener);
    }

    public class Connection extends Thread {
        /**
         * This class represents the connection between client and server.
         */

        /**
         * This method receives the objects that are sent to the client and handles them.
         * If the object is an ArrayList is fires a property change of the event name onlineUsers.
         * Which indicates that a new user has connected to the server and updates the online clients list.
         *
         * Same goes for the message instance and the string instance.
         */
        @Override
        public void run() {
            try {
                while (!Thread.currentThread().isInterrupted()) {
                    Object object = null;
                    try {
                        object = ois.readObject();
                    } catch (EOFException e) {
                        break;
                    }

                    if (object instanceof ArrayList) {
                        onlineUsers.clear();
                        onlineUsers = (ArrayList<User>) object;
                        pcs.firePropertyChange("onlineUsers", null, onlineUsers);
                    } else if (object instanceof Message) {
                        message = (Message) object;
                        String senderName = message.getSender().getUserId();
                        ImageIcon image = message.getImage();
                        String messageText = message.getText();
                        pcs.firePropertyChange("Message", null, new Object[]{senderName, messageText, image});
                        System.out.println("Client has received a message from the server");

                    } else if (object instanceof String) {
                        String message = (String) object;
                        if (message.equals("Username used")) {
                            usersWindow.dispose();
                            usersWindow.closeChatWindow();
                            loginScreen = new LoginScreen();
                            JOptionPane.showMessageDialog(null, "Username is used, try again", "Login error", JOptionPane.ERROR_MESSAGE);
                        }
                    }
                }
            } catch (Exception e) {
                e.printStackTrace();
            } finally {
                try {
                    ois.close();
                } catch (IOException e) {
                    throw new RuntimeException(e);
                }
            }
        }
    }
}
