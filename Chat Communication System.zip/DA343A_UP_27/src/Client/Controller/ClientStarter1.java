package Client.Controller;

import Client.Boundary.LoginScreen;

public class ClientStarter1 {
    public static void main(String[] args) {
        LoginScreen loginScreen = new LoginScreen();
    }
}



