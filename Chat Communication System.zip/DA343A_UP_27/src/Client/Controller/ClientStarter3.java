package Client.Controller;

import Client.Boundary.LoginScreen;

public class ClientStarter3 {
    public static void main(String[] args) {
        LoginScreen loginScreen = new LoginScreen();
    }
}



