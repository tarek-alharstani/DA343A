package Client.Boundary;

import Client.Controller.ClientController;

import javax.swing.*;
import java.awt.*;
import java.awt.event.ActionListener;
import java.util.ArrayList;
import java.util.List;

/**
 * This class will represent all the contacts.
 * It will give you the ability to see all the online users.
 * Give you the ability to choose any users to save.
 * And in here you choose which users you would like to start a chat with.
 */
public class UsersWindow extends JFrame {
    private ClientController clientController;
    private String name;
    private JList<String> onlineClientsList;
    private DefaultListModel<String> onlineClientsListModel;
    private JList<String> contactsList;
    private DefaultListModel<String> contactsListModel;
    private DefaultListModel<String> selectedReceiversListModel;
    private JList<String> selectedReceiversList;
    private JScrollPane selectedReceiversScrollPane;
    private ChatWindow chatWindow;

    /**
     * This constructor initializes the parameters and creates for us new listmodels.
     * It registers as a listener and listens for the property name onlineUsers to
     * update the usersList.
     * @param clientController
     * @param name
     * @param imagePath
     */
    public UsersWindow(ClientController clientController, String name, String imagePath) {
        this.clientController = clientController;
        this.name = name;
        this.selectedReceiversListModel = new DefaultListModel<>();
        this.selectedReceiversList = new JList<>(selectedReceiversListModel);
        this.selectedReceiversScrollPane = new JScrollPane(selectedReceiversList);
        initializeUI(imagePath);
        this.clientController.addPropertyChangeListener(evt -> {
            if ("onlineUsers".equals(evt.getPropertyName())) {

                List<String> onlineUserNames = clientController.getOnlineUserIds();
                updateOnlineClients(onlineUserNames);
                getSavedContacts();
            }
        });
        chatWindow = new ChatWindow(clientController, new ArrayList<>());
    }


    /**
     * This method is used to configure the window and adds the components
     * such as the panels to the window.
     * @param imagePath
     */
    private void initializeUI(String imagePath) {
        configureWindow();
        addComponentsToPane(imagePath);
    }

    /**
     * Configures the main window.
     */
    private void configureWindow() {
        setTitle("Chat Application");
        setSize(800, 600);
        setLocationRelativeTo(null);
        setDefaultCloseOperation(EXIT_ON_CLOSE);
    }

    /**
     * Adds the panels to the window.
     * @param imagePath
     */
    private void addComponentsToPane(String imagePath) {
        JPanel userPanel = createUserPanel(imagePath);
        JPanel contactsPanel = createContactsPanel();
        JPanel onlineClientsPanel = createOnlineClientsPanel();
        JPanel bottomLeftPanel = createRightPanel();
        configureMainPanel(contactsPanel, onlineClientsPanel, bottomLeftPanel);
        setVisible(true);
    }

    /**
     * This is the beginning where we login where our name and picture will be displayed.
     * @param imagePath
     * @return
     */
    private JPanel createUserPanel(String imagePath) {
        JPanel userPanel = new JPanel(new FlowLayout(FlowLayout.RIGHT));
        JLabel userLabel = new JLabel("Logged in as: " + name);
        userPanel.add(userLabel);
        add(userPanel, BorderLayout.NORTH);
        addUserImage(imagePath, userPanel);
        return userPanel;
    }

    /**
     * Adds out user image and scales it.
     * @param imagePath
     * @param userPanel
     */
    private void addUserImage(String imagePath, JPanel userPanel) {
        if (imagePath != null && !imagePath.isEmpty()) {
            ImageIcon icon = new ImageIcon(new ImageIcon(imagePath).getImage().getScaledInstance(50, 50, Image.SCALE_SMOOTH));
            JLabel imageLabel = new JLabel(icon);
            userPanel.add(imageLabel);
        }
    }

    /**
     * Creates out contacts panel which will be the left panel and adds the buttons to the panel.
     * @return
     */
    private JPanel createContactsPanel() {
        contactsListModel = new DefaultListModel<>();
        contactsList = new JList<>(contactsListModel);
        JPanel contactsPanel = new JPanel();
        contactsPanel.setLayout(new BoxLayout(contactsPanel, BoxLayout.Y_AXIS));
        JLabel contactsLabel = new JLabel("Contacts List:");
        contactsPanel.add(contactsLabel);
        contactsPanel.add(new JScrollPane(contactsList));
        addButtonToPanel(contactsPanel, "Add to Contacts", e -> addSelectedUsersToContacts());
        addButtonToPanel(contactsPanel, "Remove from Contacts", e -> removeSelectedContacts());
        return contactsPanel;
    }

    /**
     * Creates out online clients panel.
     * @return
     */
    private JPanel createOnlineClientsPanel() {
        onlineClientsListModel = new DefaultListModel<>();
        onlineClientsList = new JList<>(onlineClientsListModel);
        JPanel onlineClientsPanel = new JPanel();
        onlineClientsPanel.setLayout(new BoxLayout(onlineClientsPanel, BoxLayout.Y_AXIS));
        JLabel onlineClientsLabel = new JLabel("Online Clients:");
        onlineClientsPanel.add(onlineClientsLabel);
        onlineClientsPanel.add(new JScrollPane(onlineClientsList));
        return onlineClientsPanel;
    }

    /**
     * Creates out right panel where the users you choose will be sent to the chat window.
     * Adds our components to the panel.
     * @return
     */
    private JPanel createRightPanel() {
        JPanel bottomLeftPanel = new JPanel();
        bottomLeftPanel.setLayout(new BoxLayout(bottomLeftPanel, BoxLayout.Y_AXIS));

        // Open ChatWindow Button
        JButton openChatWindowButton = new JButton("Add to chatwindow");
        openChatWindowButton.setAlignmentX(Component.CENTER_ALIGNMENT);
        openChatWindowButton.addActionListener(e -> addToChatWindow());

        // Selected Receivers List
        bottomLeftPanel.add(selectedReceiversScrollPane);

        // Open ChatWindow Button
        bottomLeftPanel.add(openChatWindowButton);

        // Select Receiver Button
        JButton selectReceiverButton = new JButton("Select Receiver");
        selectReceiverButton.setAlignmentX(Component.CENTER_ALIGNMENT);
        selectReceiverButton.addActionListener(e -> selectReceiver());
        bottomLeftPanel.add(selectReceiverButton);

        // Clear Receiver List Button
        JButton clearReceiverListButton = new JButton("Clear Receiver List");
        clearReceiverListButton.setAlignmentX(Component.CENTER_ALIGNMENT);
        clearReceiverListButton.addActionListener(e -> clearReceiverList());
        bottomLeftPanel.add(clearReceiverListButton);

        // Deselect Users Button
        JButton deselectUsersButton = new JButton("Deselect Users");
        deselectUsersButton.setAlignmentX(Component.CENTER_ALIGNMENT);
        deselectUsersButton.addActionListener(e -> deselectUsers());
        bottomLeftPanel.add(deselectUsersButton);

        return bottomLeftPanel;
    }

    /**
     * Simple method to deselect marked users.
     */
    private void deselectUsers() {
        onlineClientsList.clearSelection();
        contactsList.clearSelection();
        selectedReceiversList.clearSelection();
    }

    /**
     * Method to clear our receivers list.
     */
    private void clearReceiverList() {
        selectedReceiversListModel.clear();
    }

    /**
     * Creates our main panel and adds the other panels we have created.
     * @param contactsPanel
     * @param onlineClientsPanel
     * @param bottomLeftPanel
     */
    private void configureMainPanel(JPanel contactsPanel, JPanel onlineClientsPanel, JPanel bottomLeftPanel) {
        JPanel mainPanel = new JPanel(new GridLayout(1, 3));
        mainPanel.add(contactsPanel);
        mainPanel.add(onlineClientsPanel);
        mainPanel.add(bottomLeftPanel);
        add(mainPanel, BorderLayout.CENTER);
    }

    /**
     * Method to add the buttons to the panels.
     * @param panel
     * @param buttonText
     * @param actionListener
     */
    private void addButtonToPanel(JPanel panel, String buttonText, ActionListener actionListener) {
        JButton button = new JButton(buttonText);
        button.addActionListener(actionListener);
        panel.add(button);
    }

    /**
     * When you press the add to contacts button this method adds the selected user to the contacts list.
     */
    private void addSelectedUsersToContacts() {
        List<String> selectedUsers = onlineClientsList.getSelectedValuesList();
        for (String user : selectedUsers) {
            if (!contactsListModel.contains(user)) {
                contactsListModel.addElement(user);
                saveContacts();
            }
        }
    }

    /**
     * When save contacts is pressed it saves the clients with the save contact method in
     * client controller.
     */
    private void saveContacts() {
        for (int i = 0; i < contactsListModel.size(); i++) {
            String username = contactsListModel.get(i);
            clientController.saveContact(username);
        }
    }

    /**
     * When remove contact button is pressed it removes contacts from the contacts list.
     * Could be used if you add a contact by mistake.
     */
    private void removeSelectedContacts() {
        List<String> selectedUsers = contactsList.getSelectedValuesList();
        for (String user : selectedUsers) {
            contactsListModel.removeElement(user);
        }
    }

    /**
     * Uses the clientcontrollers method to be able to load the contacts that were saved.
     */
    private void getSavedContacts() {
        List<String> savedContacts = clientController.getSavedContacts();
        contactsListModel.clear();
        //savedContacts.forEach(contactsListModel::addElement);
        DefaultListModel<String> stringDefaultListModel = contactsListModel;
        for (String savedContact : savedContacts) {
            stringDefaultListModel.addElement(savedContact);
        }
    }

    /**
     * Gives me the ability to be able to choose receivers from the onlineclientlist and contactlist
     * to add them as receivers.
     */
    private void selectReceiver() {
        List<String> selectedOnlineUsers = onlineClientsList.getSelectedValuesList();
        selectedOnlineUsers.stream().filter(user -> !selectedReceiversListModel.contains(user)).forEach(selectedReceiversListModel::addElement);
        List<String> selectedContacts = contactsList.getSelectedValuesList();
        selectedContacts.stream().filter(contact -> !selectedReceiversListModel.contains(contact)).forEach(selectedReceiversListModel::addElement);
    }

    /**
     * When a user is selected and "Add to chatwindow" button is pressed it sends the selected
     * users as an argument to be shown in the chatwindow userlist.
     */
    private void addToChatWindow() {
        if (!selectedReceiversListModel.isEmpty()) {
            ArrayList<String> receivers = new ArrayList<>();
            for (int i = 0; i < selectedReceiversListModel.size(); i++) {
                receivers.add(selectedReceiversListModel.get(i));
            }
            chatWindow.initUserList(receivers);
            chatWindow.setVisible(true);
        }
    }

    /**
     * When a new user connects this method adds them to the onlineclient listmodel.
     * @param onlineClientUserIds
     */
    private void updateOnlineClients(List<String> onlineClientUserIds) {
        onlineClientsListModel.clear();
        //onlineClientUserIds.forEach(onlineClientsListModel::addElement);
        DefaultListModel<String> stringDefaultListModel = onlineClientsListModel;
        for (String onlineClientUserId : onlineClientUserIds) {
            stringDefaultListModel.addElement(onlineClientUserId);
        }
    }

    /**
     * Method to close the chatwindow.
     */
    public void closeChatWindow() {
        chatWindow.dispose();
    }
}
