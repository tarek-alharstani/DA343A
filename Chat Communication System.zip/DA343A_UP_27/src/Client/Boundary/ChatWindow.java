package Client.Boundary;

import Client.Controller.ClientController;

import javax.swing.*;
import javax.swing.filechooser.FileNameExtensionFilter;
import javax.swing.text.BadLocationException;
import javax.swing.text.StyledDocument;
import java.awt.*;
import java.beans.PropertyChangeEvent;
import java.beans.PropertyChangeListener;
import java.io.File;
import java.time.LocalDateTime;
import java.time.format.DateTimeFormatter;
import java.util.ArrayList;
import java.util.HashMap;

/**
 * This class represents the gui where the messages will be sent and displayed.
 */

public class ChatWindow extends JFrame implements PropertyChangeListener {
    private JList<String> userList;
    private HashMap<String, JTextPane> userChatAreas;
    private JPanel chatDisplayPanel;
    private JTextField messageField;
    private JButton sendButton;
    private JButton uploadButton;
    private ClientController clientController;
    private JLabel chattingWithLabel;
    private ImageIcon uploadedImageIcon = null;
    private HashMap<String, ArrayList<Object[]>> pendingMessages = new HashMap<>();

    /**
     * This is the constructor of this class where it initializes the client controller and
     * creates a HashMap where every unique user has his own chatarea.
     * @param clientController
     * @param receivers This is where the receivers from the UsersWindow will be used.
     */
    public ChatWindow(ClientController clientController, ArrayList<String> receivers) {
        this.clientController = clientController;
        userChatAreas = new HashMap<>();

        setTitle("Chattfönster");
        setSize(800, 600);
        setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE);
        setLayout(new BorderLayout());

        chatDisplayPanel = new JPanel(new CardLayout()); // Använder CardLayout för att enkelt växla mellan JTextPanes
        JScrollPane scrollPane = new JScrollPane(); // Skapar en tom JScrollPane som senare byts ut
        chatDisplayPanel.add(scrollPane, "EMPTY");

        chattingWithLabel = new JLabel("Choose a user you would like to chat with!", SwingConstants.CENTER); // Initial text
        chattingWithLabel.setBorder(BorderFactory.createEmptyBorder(10, 0, 10, 0)); // Lite marginal ovanför och under

        JPanel chatPanel = new JPanel(new BorderLayout()); // Skapar en panel för chatarea och label
        chatPanel.add(chattingWithLabel, BorderLayout.NORTH); // Lägger till labeln ovanför chatarean
        chatPanel.add(chatDisplayPanel, BorderLayout.CENTER); // Lägger till chatDisplayPanel istället för direkt JTextPane

        add(chatPanel, BorderLayout.CENTER);

        initUserList(receivers);
        initMessageArea();

        this.clientController.addPropertyChangeListener(this);

        setVisible(true);
    }

    /**
     * This is the userlist of users you have chatted with or want to chat with.
     * Takes is receivers that are sent from the UsersWindow.
     * @param receivers
     */
    public void initUserList(ArrayList<String> receivers) {
        DefaultListModel<String> listModel = new DefaultListModel<>();
        for (String receiver : receivers) {
            listModel.addElement(receiver);
        }
        if (userList == null) {
            userList = new JList<>(listModel);
            userList.addListSelectionListener(e -> {
                if (!e.getValueIsAdjusting()) {
                    String selectedUser = userList.getSelectedValue();
                    updateChatWindow(selectedUser);
                }
            });
            JScrollPane scrollPane = new JScrollPane(userList);
            scrollPane.setPreferredSize(new Dimension(150, 0));

            // Create a label with instructions for selecting multiple receivers
            JLabel instructionLabel = new JLabel("Hold CTRL to choose more than 1 receiver");
            instructionLabel.setHorizontalAlignment(SwingConstants.RIGHT); // Align the label to the right
            JPanel instructionPanel = new JPanel(new BorderLayout());
            instructionPanel.add(instructionLabel, BorderLayout.EAST); // Add the label to the panel, aligned to the right

            JPanel listPanel = new JPanel(new BorderLayout());
            listPanel.add(instructionPanel, BorderLayout.NORTH); // Add the instruction panel at the top of the list panel
            listPanel.add(scrollPane, BorderLayout.CENTER);

            add(listPanel, BorderLayout.WEST);
        } else {
            userList.setModel(listModel);
        }
    }

    /**
     * This is the south of this window where you type in your message and adds action listeners for the
     * send button and upload image.
     * Adds the buttons to the window.
     */
    private void initMessageArea() {
        JPanel messagePanel = new JPanel(new BorderLayout());
        messageField = new JTextField();
        sendButton = new JButton("Send");
        uploadButton = new JButton("Upload image");

        sendButton.addActionListener(e -> sendMessage());
        uploadButton.addActionListener(e -> uploadImage());

        messagePanel.add(messageField, BorderLayout.CENTER);
        JPanel buttonPanel = new JPanel(new FlowLayout());
        buttonPanel.add(sendButton);
        buttonPanel.add(uploadButton);
        messagePanel.add(buttonPanel, BorderLayout.EAST);

        add(messagePanel, BorderLayout.SOUTH);
    }

    /**
     * This method allows you to upload an image from your computer that you want to send.
     */
    private void uploadImage() {
        JFileChooser fileChooser = new JFileChooser();
        FileNameExtensionFilter filter = new FileNameExtensionFilter("Pictures", "jpg", "png", "gif", "jpeg");
        fileChooser.setFileFilter(filter);

        int returnValue = fileChooser.showOpenDialog(this);
        if (returnValue == JFileChooser.APPROVE_OPTION) {
            File selectedFile = fileChooser.getSelectedFile();
            ImageIcon originalIcon = new ImageIcon(selectedFile.getAbsolutePath());

            int width = 200;
            int height = 200;
            Image scaledImage = originalIcon.getImage().getScaledInstance(width, height, Image.SCALE_SMOOTH);
            uploadedImageIcon = new ImageIcon(scaledImage);
        }
    }

    /**
     * When your message is ready and you pressed send you come to this method.
     * This takes the message, receiver and the picture you want to send to the clientcontroller.
     */
    private void sendMessage() {
        String text = messageField.getText();
        boolean hasImage = uploadedImageIcon != null;
        if (!text.isEmpty() || hasImage) {
            int[] selectedIndices = userList.getSelectedIndices();
            ArrayList<String> selectedUsers = new ArrayList<>();
            for (int index : selectedIndices) {
                selectedUsers.add(userList.getModel().getElementAt(index));
            }

            if (!selectedUsers.isEmpty()) {
                ImageIcon imageIcon = uploadedImageIcon;
                clientController.sendMessage(text, selectedUsers, imageIcon);
                for (String user : selectedUsers) {
                    appendToChat(user, text, imageIcon, true);
                }
                messageField.setText("");
                uploadedImageIcon = null;

            } else {
                JOptionPane.showMessageDialog(this, "Choose atleast 1 receiver.", "No receivers chosen", JOptionPane.WARNING_MESSAGE);
            }
        }
    }

    /**
     * This method will show you the chathistory of each user you have in your userlist.
     * Uses a hashmap where each user has a different key.
     * @param selectedUser
     */
    private void updateChatWindow(String selectedUser) {
        CardLayout cl = (CardLayout) (chatDisplayPanel.getLayout());
        if (userChatAreas.containsKey(selectedUser)) {
            cl.show(chatDisplayPanel, selectedUser);
        } else {
            JTextPane newChatArea = new JTextPane();
            newChatArea.setEditable(false);
            JScrollPane newScrollPane = new JScrollPane(newChatArea);
            chatDisplayPanel.add(newScrollPane, selectedUser);
            userChatAreas.put(selectedUser, newChatArea);
            cl.show(chatDisplayPanel, selectedUser);
        }
        chattingWithLabel.setText("Chatting with " + String.join(", ", userList.getSelectedValuesList()));

        if (pendingMessages.containsKey(selectedUser)) {
            ArrayList<Object[]> messages = pendingMessages.get(selectedUser);
            for (Object[] messageDetails : messages) {
                String message = (String) messageDetails[0];
                ImageIcon image = (ImageIcon) messageDetails[1];
                appendToChat(selectedUser, message, image, false);
            }
            pendingMessages.remove(selectedUser);
        }
    }

    /**
     * This method is displays the messages to the chat area.
     * @param userName
     * @param message
     * @param image
     * @param isSentByMe
     */
    private void appendToChat(String userName, String message, ImageIcon image, boolean isSentByMe) {
        JTextPane chatArea = userChatAreas.get(userName);
        if (chatArea == null) {
            chatArea = new JTextPane();
            chatArea.setEditable(false);
            userChatAreas.put(userName, chatArea);
            JScrollPane newScrollPane = new JScrollPane(chatArea);
            chatDisplayPanel.add(newScrollPane, userName);
        }
        try {
            StyledDocument doc = chatArea.getStyledDocument();
            LocalDateTime now = LocalDateTime.now();
            DateTimeFormatter formatter = DateTimeFormatter.ofPattern("dd:HH:mm:ss");
            String formatDateTime = now.format(formatter);

            // Determine the prefix based on whether the message is sent or received
            String prefix = isSentByMe ? "Me" : userName;

            if (message != null && !message.isEmpty()) {
                doc.insertString(doc.getLength(), formatDateTime + " " + prefix + ": " + message + "\n", null);
            }
            if (image != null) {
                chatArea.setCaretPosition(doc.getLength());
                chatArea.insertIcon(image);
                doc.insertString(doc.getLength(), "\n" + formatDateTime + "\n", null);
            }
        } catch (BadLocationException e) {
            e.printStackTrace();
        }
    }

    /**
     * This method is used when a user sends a message to me and it places the users name in the
     * userlistmodel and then appends the chat of the user to the chatarea.
     * @param senderName
     * @param message
     * @param image
     */
    public void addMessageToChat(String senderName, String message, ImageIcon image) {
        DefaultListModel<String> model = (DefaultListModel<String>) userList.getModel();
        if (!model.contains(senderName)) {
            model.addElement(senderName);
            userList.setModel(model);
        }

        if (!userChatAreas.containsKey(senderName) || !userList.getSelectedValue().equals(senderName)) {
            pendingMessages.putIfAbsent(senderName, new ArrayList<>());
            pendingMessages.get(senderName).add(new Object[]{message, image});
        } else {
            appendToChat(senderName, message, image, false);
        }
    }

    /**
     * This method listens for the propertyname "Message".
     * When a message is detected it adds the message to the chat
     *
     * @param evt A PropertyChangeEvent object describing the event source
     *          and the property that has changed.
     */
    @Override
    public void propertyChange(PropertyChangeEvent evt) {
        if ("Message".equals(evt.getPropertyName())) {
            Object[] messageDetails = (Object[]) evt.getNewValue();
            if (messageDetails.length >= 3) {
                String senderName = (String) messageDetails[0]; // Extract senders name
                String message = (String) messageDetails[1]; // Extract the message text
                ImageIcon image = (ImageIcon) messageDetails[2]; // Extract the image

                addMessageToChat(senderName, message, image);
            }
        }
    }
}