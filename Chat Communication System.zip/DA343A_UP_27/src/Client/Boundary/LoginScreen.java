package Client.Boundary;

import Client.Controller.ClientController;
import javax.swing.*;
import javax.swing.filechooser.FileNameExtensionFilter;
import java.awt.*;
import java.io.File;

/**
 * This class represents the start of the application which will be used.
 * It is where the user types in the userid and chooses profile picture.
 */
public class LoginScreen extends JFrame{
    private JFrame frame;
    private JTextField usernameField;
    private JButton chooseImageButton, connectButton;
    private JLabel imagePreview;
    private String selectedImagePath;

    /**
     * It is the constructor for this application that initializes the display method.
     */
    public LoginScreen() {
        display();
    }

    /**
     * This is the frame of the loginscreen.
     */
    public void display() {
        frame = new JFrame("Login");
        frame.setLayout(new FlowLayout());
        frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        frame.setSize(300, 200);

        usernameField = new JTextField(20);
        frame.add(usernameField);

        chooseImageButton = new JButton("Choose Image");
        chooseImageButton.addActionListener(e -> chooseImageAction());
        frame.add(chooseImageButton);

        imagePreview = new JLabel();
        frame.add(imagePreview);

        connectButton = new JButton("Connect");
        connectButton.addActionListener(e -> connectAction());
        frame.add(connectButton);

        frame.setVisible(true);
    }

    /**
     * This method allows you to choose your image.
     * It gives you the ability to choose your images from your computer.
     * It's only filtered to support images such as jpg, jpeg, png and gif.
     */
    private void chooseImageAction() {
        JFileChooser fileChooser = new JFileChooser();
        FileNameExtensionFilter filter = new FileNameExtensionFilter(
                "Image Files", "jpg", "jpeg", "png", "gif");
        fileChooser.addChoosableFileFilter(filter);
        fileChooser.setAcceptAllFileFilterUsed(false);

        int result = fileChooser.showOpenDialog(frame);
        if (result == JFileChooser.APPROVE_OPTION) {
            File selectedFile = fileChooser.getSelectedFile();
            String fileName = selectedFile.getName();
            String fileExtension = fileName.substring(fileName.lastIndexOf(".") + 1).toLowerCase();

            if (fileExtension.equals("jpg") || fileExtension.equals("jpeg") ||
                    fileExtension.equals("png") || fileExtension.equals("gif")) {

                selectedImagePath = selectedFile.getPath();

                ImageIcon originalIcon = new ImageIcon(selectedImagePath);
                Image originalImage = originalIcon.getImage();
                Image scaledImage = originalImage.getScaledInstance(100, 100, Image.SCALE_SMOOTH);
                ImageIcon imageIcon = new ImageIcon(scaledImage);
                imagePreview.setIcon(imageIcon);
                imagePreview.setPreferredSize(new Dimension(100, 100));
                frame.pack();
            } else {
                JOptionPane.showMessageDialog(frame, "Unsupported file type selected. Please select an image file.",
                        "Error", JOptionPane.ERROR_MESSAGE);
            }
        }
    }




    /**
     * This is the action that will be happening when you press on the connect button.
     * It creates an instance of ClientController and goes to the connect method.
     */
    private void connectAction() {
        String username = getUsername().trim();
        if (username.isEmpty() || selectedImagePath == null || selectedImagePath.trim().isEmpty()) {
            JOptionPane.showMessageDialog(frame, "Make sure you have a username and picture", "Login Error", JOptionPane.ERROR_MESSAGE);
        } else {
            new ClientController("localHost", 2243, username, selectedImagePath).connect(username, selectedImagePath);
            closeGui();
        }
    }

    /**
     * Method to get the username from the text field.
     * @return
     */
    public String getUsername() {
        return usernameField.getText();
    }

    /**
     * Method to be able to close this gui.
     */
    public void closeGui() {
        frame.dispose();
    }
}
