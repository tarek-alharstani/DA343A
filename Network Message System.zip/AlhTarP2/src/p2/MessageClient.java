package p2;

import java.io.ObjectInputStream;
import java.net.Socket;
import java.util.ArrayList;
import java.util.Iterator;

/**
 * Represents a client that connects to a message server and listens for incoming messages.
 */
public class MessageClient {

    private Buffer<Message> messageBuffer;
    private ArrayList<Callback> callbackList;

    /**
     * Constructs a MessageClient with the given address and port.
     *
     * @param address The address of the message server.
     * @param port    The port on which the message server listens.
     * @ Writer  Tarek alharstani
     */
    public MessageClient(String address, int port) {
        new Connection(address, port);
        callbackList = new ArrayList<Callback>();
        messageBuffer = new Buffer<Message>();
    }

    /**
     * Adds a callback listener to the client.
     *
     * @param ci The callback listener to be added.
     */
    public void addListener(Callback ci) {
        callbackList.add(ci);
    }

    /**
     * Sends a received message to all registered callback listeners.
     *
     * @param msg The message to be sent to listeners.
     */
    private void sendList(Message msg) {
        Iterator<Callback> iter = callbackList.iterator();
        while(iter.hasNext()) {
            iter.next().getMessage(msg);
        }
    }

    /**
     * A thread responsible for establishing a connection to the message server and listening for incoming messages.
     */
    private class Connection extends Thread {

        private String address;
        private int port;

        /**
         * Constructs a Connection with the given address and port and starts the thread.
         *
         * @param address The address of the message server.
         * @param port    The port on which the message server listens.
         */
        public Connection(String address, int port) {
            this.address = address;
            this.port = port;
            start();
        }

        /**
         * Establishes a connection to the message server and continuously listens for incoming messages.
         */
        public void run() {
            try (Socket socket = new Socket(address, port)) {
                ObjectInputStream ois = new ObjectInputStream(socket.getInputStream());
                while (true) {
                    try {
                        Message msg = (Message) ois.readObject();
                        messageBuffer.put(msg);
                        sendList(msg);
                    } catch (Exception e) {
                        e.printStackTrace();
                    }
                }
            } catch (Exception e) {
                e.printStackTrace();
                System.out.println("Something's wrong!!!!!!");
            }
        }
    }
}
