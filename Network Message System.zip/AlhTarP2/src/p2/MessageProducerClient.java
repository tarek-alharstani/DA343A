package p2;

import java.io.ObjectOutputStream;
import java.net.Socket;

/**
 * Klassen MessageProducerClient representerar en klient som skickar MessageProducers till en server.
 */
public class MessageProducerClient {

    private String address;
    private int port;

    /**
     * Konstruerar en MessageProducerClient med den angivna adressen och porten.
     *
     * @param address Adressen till servern.
     * @param port Portnumret till servern.
     */
    public MessageProducerClient(String address, int port) {
        this.address = address;
        this.port = port;
    }

    /**
     * Skickar en MessageProducer till servern.
     *
     * @param producer MessageProducer att skicka.
     */
    public void send(MessageProducer producer) {
        ArrayProducer arrayProducer = null;
        int times = 0;
        int delay = 0;
        int size = 0;

        // Hämtar parametrar från MessageProducer
        times = producer.times();
        delay = producer.delay();
        size = producer.size();
        Message[] messages = new Message[size];

        // Genererar meddelanden från MessageProducer
        for (int i = 0; i < size; i++) {
            messages[i] = producer.nextMessage();
        }

        // Skapar en ArrayProducer med de genererade meddelandena
        arrayProducer = new ArrayProducer(messages, times, delay);

        try (Socket socket = new Socket(address, port)) {
            // Skickar ArrayProducer-objektet till servern
            ObjectOutputStream oos = new ObjectOutputStream(socket.getOutputStream());
            ArrayProducer obj = arrayProducer;
            oos.writeObject(obj);
            Thread.sleep(500);
            oos.flush();
            oos.close();
        } catch (Exception e) {
            e.printStackTrace();
        }
    }
}
