package p2;

import javax.swing.*;
import java.io.BufferedReader;
import java.io.FileInputStream;
import java.io.InputStreamReader;

/**
 * En klass som hämtar en textfil och läser innehållet för att skapa
 * {@link Message} objekt.
 * @author Tarek alharstani
 */
public class TextfileProducer implements MessageProducer {

    private int times = 0;
    private int delay = 0;

    private Message[] messages;
    private int presentIndex = -1;

    /**
     * skapar en P2.TextfileProducer-instans från angivna fil.
     * Den läser filen rad för rad och använder informationen
     * för att fylla en array med meddelanden, varje meddelande innehåller text och en bild
     *
     */
    public TextfileProducer(String filename)  {
        try (BufferedReader br = new BufferedReader(new InputStreamReader(new FileInputStream(filename), "UTF-8"))) {
            times = Integer.parseInt(br.readLine());
            delay = Integer.parseInt(br.readLine());
            int size  = Integer.parseInt(br.readLine());

            // Skapar en array för att lagra meddelandena.
            messages = new Message[size];

            for (int i = 0; i < messages.length; i++) {
                // läser in text och ikon för varje meddelande.
                String text = br.readLine();

                // Läser in sökvägen till ikonen och skapar en ImageIcon.
                ImageIcon icon = new ImageIcon(br.readLine());
                // Skapar ett nytt P2.Message-objekt med texten och ikonen och lägger till det i arrayen.
                messages[i] = new Message(text,icon);
            }
            //br.close();

            info();
        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    /**
     * Returnerar antalet millisekunder (ms) mellan varje visning av ett {@link Message}-objekt.
     *
     * @return Antalet millisekunder (ms) för fördröjningen mellan varje meddelande.
     */
    @Override
    public int delay() {
        return delay;
    }

    /**
     * Returnerar antal gånger sekvensen ska visas.
     *
     */
    @Override
    public int times() {
        return times;
    }

    /**
     * returneras antingen längden på arrayen messages
     * om den inte är null,
     * annars returneras 0.
     */
    @Override
    public int size() {
        return (messages == null) ? 0 : messages.length;
    }


    /**
     * kontrollerar om storleken på meddelandelistan är 0
     * och om messages är null innan
     * den fortsätter med att returnera nästa meddelande.
     */
    @Override
    public Message nextMessage() {
        if (size() == 0 || messages == null) {
            return null;
        }
        presentIndex = (presentIndex + 1) % messages.length; // Uppdaterar index för nästa meddelande.
        return messages[presentIndex];                        // Returnerar nästa meddelande från arrayen.
    }


}
