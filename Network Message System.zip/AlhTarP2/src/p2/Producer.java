package p2;

/**
 *En trådklass som producerar meddelanden
 * och sätter dem i en buffert för meddelanden.
 * @author Tarek alharstani
 */
public class Producer extends Thread {

    private Buffer<MessageProducer> producerBuffer;
    private Buffer<Message> messageBuffer;
    /**
     * Konstruktor för att skapa en P2.Producer.
     * @param prodBuffer Buffert för P2.MessageProducer-objekt.
     * @param messageBuffer Buffert för meddelanden.
     */

    public Producer(Buffer<MessageProducer> prodBuffer, Buffer<Message> messageBuffer) {
        producerBuffer = prodBuffer;
        this.messageBuffer = messageBuffer;
    }



    /**
     * Metod som körs när tråden startas.
     * Producerar meddelanden från P2.MessageProducer-objekt och lägger dem i meddelandebufferten.
     */
    @Override
    public void run() {
        while (!Thread.interrupted()) { // Loopa tills tråden avbryts.
            try {
                MessageProducer mp = producerBuffer.get(); // Hämtar P2.MessageProducer från bufferten.
                for (int times = 0; times < mp.times(); times++) {// Loopa antalet gånger som specificerats av P2.MessageProducer
                    for (int i = 0; i < mp.size(); i++) {  // Loopa genom meddelanden som specificerats av P2.MessageProducer.
                        messageBuffer.put(mp.nextMessage());
                        Thread.sleep(mp.delay()); // Fördröj meddelandet enligt specificerad fördröjning i P2.MessageProducer.

                    }
                }
            } catch (InterruptedException e) {
                e.printStackTrace(); // Hantera avbrott genom att skriva ut felmeddelandet.
            }
        }
    }
    /**
     * Startar tråden.
     * Överstiger Thread-start-metoden för att kunna använda synchronized.
     */
    @Override
    public synchronized void start() {
        super.start();
    }
}
