package p2;

import javax.swing.*;
import java.io.Serializable;

/**
 * En klass som representerar ett meddelande med en text och en ikon.
 * Implementerar Serializable för att möjliggöra serialisering.
 * @author Tarek alharstani
 */
public class Message implements Serializable {


    private String text;
    /**
     * Icon är ett gränssnitt i Java som
     * representerar grafiska ikoner i användargränssnitt.
     * Det används för att abstrahera över olika typer av ikoner, som bilder
     */
    private Icon icon;
    /**
     * Konstruktor för att skapa ett P2.Message-objekt med given text och ikon.
     * @param text Texten i meddelandet.
     * @param icon Ikonen i meddelandet.
     *
     */
    public Message(String text, Icon icon) {
        this.text = text; // Tilldela texten.
        this.icon = icon; // Tilldela ikonen.
    }
    /**
     * Returnerar texten i meddelandet.
     * @return Texten i meddelandet.
     */
    public String getText() {
        return text;
    }
    /**
     * Returnerar ikonen i meddelandet.
     * @return Ikonen i meddelandet.
     */
    public Icon getIcon() {
        return icon;
    }
}
