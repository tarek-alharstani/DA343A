package p2;

import java.io.ObjectOutputStream;
import java.net.ServerSocket;
import java.net.Socket;
import java.util.ArrayList;
import java.util.Iterator;
import java.util.Observable;
import java.util.Observer;

/**
 * The MessageServer class represents a server that manages incoming client connections
 * and distributes messages to all connected clients.
 */
public class MessageServer {

    private MessageManager mm;
    private int port;

    private ArrayList<ClientHandler> clients;
    private Thread server;

    /**
     * Constructs a MessageServer with the given MessageManager and port.
     * Initializes the list of clients and starts the server thread.
     *
     * @param messageManager The MessageManager responsible for managing messages.
     * @param port           The port on which the server listens for connections.
     */
    public MessageServer(MessageManager messageManager, int port) {
        this.mm = messageManager;
        this.port = port;
        clients = new ArrayList<ClientHandler>(); // to hold client handling objects
        mm.addObserver(new MMObserver());
        server = new Connection(port);
    }

    /**
     * Sends a message to all connected clients.
     *
     * @param msg The message to be sent.
     */
    private void send2Clients(Message msg) {
        Iterator<ClientHandler> iter = clients.iterator();
        while (iter.hasNext()) {
            iter.next().put(msg);
        }
    }

    /**
     * A thread responsible for accepting incoming client connections.
     */
    private class Connection extends Thread {

        private int port;

        /**
         * Constructor for Connection thread.
         *
         * @param port The port to listen for incoming connections.
         */
        public Connection(int port) {
            this.port = port;
            start();
        }

        /**
         * Listens for incoming client connections and creates a ClientHandler for each connection.
         */
        public void run() {
            try (ServerSocket serverSocket = new ServerSocket(port)) {
                System.out.println("MessageServer Started");
                while (true) {
                    try {
                        Socket socket = serverSocket.accept();
                        ClientHandler client = new ClientHandler(socket);
                        clients.add(client);
                    } catch (Exception e) {
                        e.printStackTrace();
                    }
                }
            } catch (Exception e) {
                e.printStackTrace();
            }
        }
    }

    /**
     * Represents a handler for a connected client.
     */
    private class ClientHandler extends Thread {

        private Socket socket;

        private Buffer<Message> messageBuffer;

        /**
         * Constructor for ClientHandler.
         *
         * @param socket The socket associated with the client connection.
         */
        public ClientHandler(Socket socket) {
            this.socket = socket;
            messageBuffer = new Buffer<Message>();
            start();
        }

        /**
         * Puts a message into the client's message buffer.
         *
         * @param msg The message to be put into the buffer.
         */
        public void put(Message msg) {
            messageBuffer.put(msg);
        }

        /**
         * Continuously listens for messages from the messageBuffer and sends them to the client.
         */
        public void run() {
            try {
                ObjectOutputStream oos = new ObjectOutputStream(socket.getOutputStream());
                while (true) {
                    try {
                        Message msg = messageBuffer.get();
                        oos.writeObject(msg);
                        oos.flush();
                    } catch (Exception e) {
                        e.printStackTrace();
                    }
                }
            } catch (Exception e) {
                e.printStackTrace();
            }
        }

    }

    /**
     * An Observer implementation that sends incoming messages to all connected clients.
     */
    private class MMObserver implements Observer {
        /**
         * Update method called by the observed object.
         * Sends the incoming message to all connected clients.
         *
         * @param o   The Observable object.
         * @param arg The message received from the Observable.
         */
        public void update(Observable o, Object arg) {
            Message msg = (Message) arg;
            send2Clients(msg);
        }
    }
}
