package p2;


import java.util.Observable;
import java.util.Observer;

@SuppressWarnings("deprecation")

public class P1Viewer extends Viewer{

    /**
     * Konstruktor för att skapa en P1Viewer.
     * @param messageManager En MessageManager som hanterar meddelanden.
     * @param xSize Storleken på x-axeln för visningsfönstret.
     * @param ySize Storleken på y-axeln för visningsfönstret.
     * @author Tarek alharstani
     */
    public P1Viewer(MessageManager messageManager, int xSize, int ySize) {
        super(xSize,ySize);
        messageManager.addObserver(new MessageObserver());
        // Lägg till en MessageObserver till MessageManager som en observatör.
    }
    /**
     * Metod för att skicka ett meddelande till Viewer-komponenten.
     * @param msg Meddelandet att skicka till Viewer-komponenten.
     */
    private void sendMsg(Message msg) {
        super.setMessage(msg);
        // Anropa superklassens setMessage-metod för att skicka meddelandet till Viewer.
    }

    /**
     * En inre klass som fungerar som en Observer för meddelanden.
     */
    private class MessageObserver implements Observer {

        /**
         * Metod som anropas när en observerad MessageManager har uppdaterats med ett nytt meddelande.
         * @param o Den Observable-objektet som är uppdaterat (MessageManager i detta fall).
         * @param arg Det objekt som skickas med när Observable-objektet uppdateras (meddelandet i detta fall).
         */
        @Override
        public void update(Observable o, Object arg) {
            Message msg = (Message)arg;
            sendMsg(msg); // Skicka meddelandet till Viewer-komponenten.
        }

    }
}
