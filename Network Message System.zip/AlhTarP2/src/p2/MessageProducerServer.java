package p2;

import java.io.ObjectInputStream;
import java.net.ServerSocket;
import java.net.Socket;

/**
 * The MessageProducerServer class represents a server that listens for incoming connections
 * and accepts MessageProducers.
 *
 * @author Tarek alharstani
 */
public class MessageProducerServer {

    private Thread server; // Thread object to handle server operations
    private MessageProducerInput MPI; // Input handler for MessageProducers

    /**
     * Constructs a MessageProducerServer with the specified MessageProducerInput and port.
     *
     * @param mpInput The MessageProducerInput object to use for adding MessageProducers.
     * @param port The port number to listen on.
     */
    public MessageProducerServer(MessageProducerInput mpInput, int port) {
        this.MPI = mpInput;
        server = new ConnectionHandler(port);
    }

    /**
     * Starts the server thread.
     */
    public void startServer() {
        server.start();
    }

    // Inner class representing the connection handler thread
    private class ConnectionHandler extends Thread {

        private int port; // The port to listen on

        /**
         * Constructs a ConnectionHandler with the specified port.
         *
         * @param port The port number to listen on.
         */
        // för att hantera inkommande anslutningar och läsa in meddelanden.
        // Den här tråden skapas i konstruktorn och startas när startServer()-metoden anropas
        public ConnectionHandler(int port) {
            this.port = port;
        }

        /**
         * Runs the server thread, accepting incoming connections and adding MessageProducers.
         */
        public void run() {

            try (ServerSocket servSocket = new ServerSocket(port)) {

                System.out.println("P2.MessageProducerServer is started"); // Skriv ut att servern har startats
                while (true) { // Loop för lyssna efter inkommande anslutningar
                    Socket socket = servSocket.accept(); // Acceptera inkommande anslutning
                    ObjectInputStream ois = new ObjectInputStream(socket.getInputStream()); // Skapa en ObjectInputStream för att läsa inkommande data
                    ArrayProducer ap = (ArrayProducer) ois.readObject();
                    MPI.addMessageProducer(ap); // Lägg till ArrayProducer-objektet i MessageProducerInput (MPI)
                    socket.close();
                }
            } catch (Exception e) {
                e.printStackTrace();
                System.out.println("Something's wrong!!!!!!");
            }
        }

    }
}
