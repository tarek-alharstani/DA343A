package p2;

import java.util.Observable;

public class MessageManager extends Observable implements Runnable {

    private Buffer<Message> messageBuffer; // Buffern för meddelanden som ska hanteras.
    private Thread thread; // Tråden för att köra hanteringen av meddelanden.

    /**
     * Konstruktor för att skapa en P2.MessageManager.
     * @param messageBuffer Buffern för meddelanden som ska hanteras.
     * @author Tarek alharstani
     */
    public MessageManager(Buffer<Message> messageBuffer) {
        this.messageBuffer = messageBuffer;
    }

    /**
     * Metod som körs när tråden startas.
     * Loopar genom buffern för att hämta och skriva ut meddelanden.
     */
    @Override
    public void run() {
        while (!Thread.interrupted()) {
            try {
                Message msg = messageBuffer.get();
                System.out.println(msg.getText());
                setChanged();
                notifyObservers(msg);
            } catch (InterruptedException e) {
                e.printStackTrace();
                System.out.println("Something's wrong!!!!!!");

            }
        }
    }
    /**
     * Metod för att starta hanteringen av meddelanden i en ny tråd.
     */
    public void start() {
        if (thread == null) {
            thread = new Thread(this);
            thread.start();
        }
    }


}

