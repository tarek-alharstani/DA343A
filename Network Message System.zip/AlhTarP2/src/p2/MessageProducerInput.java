package p2;

/**
 * En klass som hanterar inmatning av P2.MessageProducer-objekt till en buffert.
 * * @author Tarek alharstani
 */
public class MessageProducerInput {

    private Buffer<MessageProducer> producerBuffer;

    /**
     * Konstruktor för att skapa en P2.MessageProducerInput.
     * @param mp En buffert för P2.MessageProducer-objekt.
     */
    public MessageProducerInput(Buffer<MessageProducer> mp) {
        producerBuffer = mp;
    }

    /**
     * Lägger till ett P2.MessageProducer-objekt till bufferten.
     * @param m P2.MessageProducer-objektet som ska läggas till i bufferten.
     */
    public void addMessageProducer(MessageProducer m) {
        producerBuffer.put(m);
    }

}
