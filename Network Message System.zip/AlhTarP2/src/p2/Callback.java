package p2;

public interface Callback {
    public void getMessage(Message msg);
}
