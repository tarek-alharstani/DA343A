package p2;

import java.io.BufferedInputStream;
import java.io.FileInputStream;
import java.io.ObjectInputStream;

public class ObjectfileProducer implements MessageProducer {

    private int times = 0;
    private int delay = 0;
    private Message[] messages;
    private int currentIndex = -1;

    /**
     * Konstruktor för att skapa en P2.ObjectfileProducer.
     * Läser in data från en angiven fil för att initialisera variabler och meddelande-arrayen.
     * @param filename Filnamnet från vilken data läses in.
     */
    public ObjectfileProducer(String filename) {
        try (ObjectInputStream ois = new ObjectInputStream(new BufferedInputStream(new FileInputStream(filename)))) {

            times    = ois.readInt(); // Läs antalet gånger meddelandena ska visas från filen.
            delay    = ois.readInt();  // Läs fördröjningen mellan meddelandena från filen.
            int size = ois.readInt();  // Läs storleken på meddelande-arrayen från filen.

            messages = new Message[size];

            // Läs in varje meddelande från filen och lägg till dem i meddelande-arrayen.
            for (int i = 0; i < messages.length; i++) {
                messages[i] = (Message) ois.readObject();
            }

            info(); // Anropas för: visa information om läsningen
        } catch (Exception e) {
            e.printStackTrace(); // Hantera eventuella fel genom att skriva ut felmeddelandet.
        }
    }

    /**
     * Returnerar fördröjningen (i millisekunder) mellan varje visning av meddelandena.
     * @return Fördröjningen (i millisekunder) mellan varje meddelande.
     */
    @Override
    public int delay() {
        return delay;
    }

    /**
     * Returnerar antalet gånger meddelandena ska visas.
     * @return Antalet gånger meddelandena ska visas.
     */
    @Override
    public int times() {
        return times;
    }

    /**
     * Returnerar storleken på meddelande-arrayen.
     * Om arrayen är null returneras 0.
     * @return Storleken på meddelande-arrayen.
     */
    @Override
    public int size() {
        if (messages == null) {
            return 0; // Om arrayen är null, returnera 0.
        } else {
            return messages.length; // Annars,returnera storleken på arrayen.
        }
    }

    /**
     * Returnerar nästa meddelande som ska visas.
     * @return Nästa meddelande att visas.
     */
    @Override
    public Message nextMessage() {
        if (size() == 0) {
            return null;
        }
        currentIndex = (currentIndex + 1) % messages.length; // Uppdatera index för nästa meddelande.
        return messages[currentIndex]; // Returnera nästa meddelande.
    }

}


