package p2;


public class P2Viewer extends Viewer {

    // Privat instansvariabel för att hålla en instans av MessageClient.
    private MessageClient mc;


    public P2Viewer(MessageClient messageClient, int xSize, int ySize) {
        // Anropa superklassens konstruktor och skicka med xSize och ySize.
        super(xSize, ySize);

        this.mc = messageClient;
        // Lägg till en lyssnare för meddelandeclienten med en ny instans av CallbackController.
        mc.addListener(new CallbackController());
    }


    public void setMessage(Message msg) {
        // Anropa superklassens setMessage-metod och skicka meddelandet vidare.
        super.setMessage(msg);
    }


    class CallbackController implements Callback {

        public void getMessage(Message msg) {
            // Anropa P2Viewer's setMessage-metod för att sätta det mottagna meddelandet.
            setMessage(msg);
        }
    }
}
